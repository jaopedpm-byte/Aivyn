package com.meu.assistente

import android.accessibilityservice.AccessibilityService
import android.content.Context

/** Interpreta comandos (digitados ou falados) e executa. */
class Brain(ctx: Context, private val say: (String) -> Unit) {
    private val db = MemoryDb(ctx)

    private fun arg(t: String, vararg prefixes: String): String? {
        val l = t.lowercase()
        for (p in prefixes) if (l.startsWith(p)) return t.substring(p.length).trim()
        return null
    }

    fun handle(raw: String) {
        val t = raw.trim().trimEnd('.', '!', '?')
        if (t.isEmpty()) return
        val l = t.lowercase()
        db.log(t)
        val acc = AssistantAccessibilityService.instance

        // --- aprendizado ---
        arg(t, "aprenda que ", "lembre que ", "lembre-se que ")?.let { learn(it); return }
        arg(t, "esqueça que ", "esqueça ")?.let { db.forget(it); say("Esqueci $it"); return }
        arg(t, "o que é ", "quem é ", "o que você sabe sobre ", "o que eu te disse sobre ")?.let {
            say(db.recall(it) ?: "Ainda não sei sobre $it"); return
        }

        // --- fala ---
        arg(t, "fale ", "diga ")?.let { say(it); return }

        // --- ações na tela (precisam de acessibilidade) ---
        val needsAcc = l.startsWith("clique em ") || l.startsWith("toque em ") || l.startsWith("aperte ") ||
            l.startsWith("digite ") || l.startsWith("escreva ") || l in setOf(
            "voltar", "início", "inicio", "home", "tela inicial", "recentes", "notificações",
            "role para baixo", "role para cima", "leia a tela"
        )
        if (needsAcc && acc == null) { say("Ative o serviço de acessibilidade do assistente"); return }
        if (acc != null) {
            arg(t, "clique em ", "toque em ", "aperte ")?.let {
                say(if (acc.clickByText(it)) "Cliquei em $it" else "Não achei $it na tela"); return
            }
            arg(t, "digite ", "escreva ")?.let {
                say(if (acc.typeText(it)) "Digitei" else "Nenhum campo de texto selecionado"); return
            }
            when (l) {
                "voltar" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); return }
                "início", "inicio", "home", "tela inicial" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return }
                "recentes" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); return }
                "notificações" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); return }
                "role para baixo" -> { acc.scroll(true); return }
                "role para cima" -> { acc.scroll(false); return }
                "leia a tela" -> { say(acc.screenText().take(500).ifBlank { "Não vi texto na tela" }); return }
            }
        }

        say(db.recall(l) ?: "Ainda não sei isso. Me ensine: aprenda que isso é aquilo")
    }

    private fun learn(s: String) {
        val m = Regex("^(.+?) (é|são|significa) (.+)$", RegexOption.IGNORE_CASE).find(s)
        if (m == null) { say("Diga assim: aprenda que isso é aquilo"); return }
        db.learn(m.groupValues[1], m.groupValues[3])
        say("Anotado: ${m.groupValues[1]} é ${m.groupValues[3]}")
    }
}
