package com.meu.assistente

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Banco local no próprio celular: fatos aprendidos + histórico do que você disse. */
class MemoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "assistente.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE facts(k TEXT PRIMARY KEY, v TEXT NOT NULL, ts INTEGER)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, said TEXT, ts INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun learn(k: String, v: String) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO facts VALUES(?,?,?)",
            arrayOf(k.lowercase().trim(), v.trim(), System.currentTimeMillis())
        )
    }

    fun recall(k: String): String? {
        val key = k.lowercase().trim()
        readableDatabase.rawQuery("SELECT v FROM facts WHERE k=?", arrayOf(key)).use {
            if (it.moveToFirst()) return it.getString(0)
        }
        readableDatabase.rawQuery("SELECT k, v FROM facts WHERE k LIKE ? LIMIT 1", arrayOf("%$key%")).use {
            if (it.moveToFirst()) return it.getString(1)
        }
        return null
    }

    fun forget(k: String) {
        writableDatabase.execSQL("DELETE FROM facts WHERE k=?", arrayOf(k.lowercase().trim()))
    }

    fun log(said: String) {
        writableDatabase.execSQL("INSERT INTO history(said, ts) VALUES(?,?)", arrayOf(said, System.currentTimeMillis()))
    }
}
