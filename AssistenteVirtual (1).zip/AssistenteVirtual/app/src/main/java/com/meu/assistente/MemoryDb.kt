package com.meu.assistente

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Banco local no próprio celular: fatos aprendidos + histórico do que você disse. */
class MemoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "assistente.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE facts(k TEXT PRIMARY KEY, v TEXT NOT NULL, ts INTEGER)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, said TEXT, ts INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    /** Normaliza a chave: minúsculas, sem pontuação final e sem artigo inicial (o, a, um...). */
    private fun norm(k: String) = k.lowercase().trim().trimEnd('?', '.', '!', ',')
        .replace(Regex("^(o|a|os|as|um|uma) "), "").trim()

    fun learn(k: String, v: String) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO facts VALUES(?,?,?)",
            arrayOf(norm(k), v.trim().trimEnd('.', '!'), System.currentTimeMillis())
        )
    }

    /** Devolve (chave, valor) ou null. */
    fun recall(k: String): Pair<String, String>? {
        val key = norm(k)
        if (key.isEmpty()) return null
        readableDatabase.rawQuery("SELECT k, v FROM facts WHERE k=?", arrayOf(key)).use {
            if (it.moveToFirst()) return Pair(it.getString(0), it.getString(1))
        }
        readableDatabase.rawQuery("SELECT k, v FROM facts WHERE k LIKE ? LIMIT 1", arrayOf("%$key%")).use {
            if (it.moveToFirst()) return Pair(it.getString(0), it.getString(1))
        }
        return null
    }

    fun forget(k: String) {
        writableDatabase.execSQL("DELETE FROM facts WHERE k=?", arrayOf(norm(k)))
    }

    fun log(said: String) {
        writableDatabase.execSQL("INSERT INTO history(said, ts) VALUES(?,?)", arrayOf(said, System.currentTimeMillis()))
    }
}
