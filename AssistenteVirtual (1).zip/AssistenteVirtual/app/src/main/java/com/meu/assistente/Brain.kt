package com.meu.assistente

import android.accessibilityservice.AccessibilityService
import android.content.Context

/** Interpreta comandos (digitados ou falados) e executa. */
class Brain(ctx: Context, private val say: (String) -> Unit) {
    private val db = MemoryDb(ctx)

    private fun arg(t: String, vararg prefixes: String): String? {
        val l = t.lowercase()
        for (p in prefixes) if (l.startsWith(p)) return t.substring(p.length).trim()
        return null
    }

    private fun answer(k: String, v: String): String {
        val kk = when {
            k.startsWith("meu ") -> "seu " + k.removePrefix("meu ")
            k.startsWith("minha ") -> "sua " + k.removePrefix("minha ")
            else -> k
        }
        return "$kk é $v"
    }

    private val statement = Regex("^(.+?) (é|são|significa) (.+)$", RegexOption.IGNORE_CASE)

    fun handle(raw: String) {
        val t = raw.trim().trimEnd('.', '!', '?')
        if (t.isEmpty()) return
        val l = t.lowercase()
        db.log(t)
        val acc = AssistantAccessibilityService.instance

        // --- ensinar (explícito) ---
        arg(t, "aprenda que ", "aprende que ", "aprenda ", "aprende ", "lembre-se de que ", "lembre-se que ",
            "lembre que ", "memorize que ", "memorize ", "anote que ", "anote ", "guarde que ", "guarde ", "saiba que ")
            ?.let { learn(it); return }

        arg(t, "esqueça que ", "esqueça ")?.let { db.forget(it); say("Esqueci $it"); return }

        // --- perguntar ---
        arg(t, "qual é ", "qual o ", "qual a ", "quais são ", "o que é ", "o que são ", "quem é ", "quem são ",
            "o que você sabe sobre ", "o que eu te disse sobre ", "me fale sobre ", "fale sobre ")?.let { k ->
            val r = db.recall(k)
            say(if (r != null) answer(r.first, r.second) else "Ainda não sei. Me ensine falando, por exemplo: $k é alguma coisa")
            return
        }

        // --- fala ---
        arg(t, "fale ", "diga ")?.let { say(it); return }

        // --- ações na tela (precisam de acessibilidade) ---
        val needsAcc = l.startsWith("clique em ") || l.startsWith("toque em ") || l.startsWith("aperte ") ||
            l.startsWith("digite ") || l.startsWith("escreva ") || l in setOf(
            "voltar", "início", "inicio", "home", "tela inicial", "recentes", "notificações",
            "role para baixo", "role para cima", "leia a tela"
        )
        if (needsAcc && acc == null) { say("Ative o serviço de acessibilidade do assistente"); return }
        if (acc != null) {
            arg(t, "clique em ", "toque em ", "aperte ")?.let {
                say(if (acc.clickByText(it)) "Cliquei em $it" else "Não achei $it na tela"); return
            }
            arg(t, "digite ", "escreva ")?.let {
                say(if (acc.typeText(it)) "Digitei" else "Nenhum campo de texto selecionado"); return
            }
            when (l) {
                "voltar" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); return }
                "início", "inicio", "home", "tela inicial" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return }
                "recentes" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); return }
                "notificações" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); return }
                "role para baixo" -> { acc.scroll(true); return }
                "role para cima" -> { acc.scroll(false); return }
                "leia a tela" -> { say(acc.screenText().take(500).ifBlank { "Não vi texto na tela" }); return }
            }
        }

        // --- se disse só o assunto, responde o que sabe ---
        db.recall(l)?.let { say(answer(it.first, it.second)); return }

        // --- frase afirmativa ("meu nome é João") aprende sozinho ---
        if (statement.containsMatchIn(t)) { learn(t); return }

        say("Não entendi. Para me ensinar, fale uma frase como: meu nome é João")
    }

    private fun learn(s: String) {
        val m = statement.find(s.trim())
        if (m == null) { say("Não consegui entender. Fale assim: meu nome é João"); return }
        db.learn(m.groupValues[1], m.groupValues[3])
        say("Anotado! ${answer(m.groupValues[1].lowercase(), m.groupValues[3])}")
    }
}
