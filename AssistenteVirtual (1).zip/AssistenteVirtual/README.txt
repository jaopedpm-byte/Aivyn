Assistente Virtual - projeto Android (Kotlin). Veja as instruções no chat.
